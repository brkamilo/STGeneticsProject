USE [STGenetics]
GO

CREATE TABLE [Order](
	[OrderId] INT PRIMARY KEY IDENTITY(1,1),
	[Total] DECIMAL(18,2) NOT NULL
)

