USE [STGenetics]
GO

CREATE TABLE Animal(
	[AnimalId] INT PRIMARY KEY IDENTITY(1,1),
	[Name] VARCHAR(50) NOT NULL,
	[Breed] VARCHAR(50) NOT NULL,
	[BirthDate] DATE NOT NULL,
	[Sex] VARCHAR(50) NOT NULL,
	[Price] DECIMAL(10,2) NOT NULL,
	[Status] bit NOT NULL
)