USE [STGenetics]
GO

CREATE TABLE [User](
	[UserId] INT PRIMARY KEY IDENTITY(1,1),
	[UserName] VARCHAR (100)  NOT NULL,
	[Password] VARCHAR (100)  NOT NULL,
	[Role] VARCHAR (100)  NOT NULL
)

INSERT INTO [User]
VALUES ('Camilo', '123', 'employee')

INSERT INTO [User]
VALUES ('Braian', '123', 'employee')
