USE [STGenetics]
GO

DECLARE @n INT = 1;

WHILE(@n <= 5000)
BEGIN
	DECLARE @name VARCHAR(50) = CONCAT('Animal_', @n);
	DECLARE @breedId INT = FLOOR(RAND() * 12)+ 1; 
	DECLARE @birthDate DATE = DATEADD(day, -RAND() * 3650, GETDATE());
	DECLARE @sex Varchar(10) = IIF(RAND() > 0.5, 'Male', 'Female'); 
	DECLARE @price DECIMAL(10, 2) = ROUND(RAND() * 10000, 2);
	DECLARE @status BIT = IIF(RAND() > 0.5, 0, 1); 	

	INSERT INTO Animal ([Name], Breed, BirthDate, Sex, Price, [Status])
	VALUES (@name, (SELECT [Name] FROM Breed WHERE BreedId = @breedId), @birthDate, @sex, @price, @status)

	SET @n = @n + 1;
END;