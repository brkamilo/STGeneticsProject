USE [STGenetics]
GO

CREATE PROCEDURE spCreateAnimal(
@Name VARCHAR(50),
@Breed VARCHAR(50),
@BirthDate DATE,
@Sex VARCHAR(50),
@Price Decimal(10,2),
@status BIT
)
AS
BEGIN
	INSERT INTO [dbo].[Animal]
	VALUES (@Name, @Breed, @BirthDate, @Sex, @Price, @status)
END