USE [STGenetics]
GO

CREATE PROCEDURE spDeleteAnimal(
@Id int
)
AS
BEGIN
	DELETE FROM [dbo].[Animal]
	WHERE AnimalId = @Id
END