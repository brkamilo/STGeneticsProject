USE [STGenetics]
GO

CREATE PROCEDURE spUpdateAnimal(
@AnimalId int,
@Name VARCHAR(50),
@Breed VARCHAR(50),
@BirthDate DATE,
@Sex VARCHAR(50),
@Price Decimal(10,2),
@Status BIT
)
AS
BEGIN
	UPDATE [dbo].[Animal]
	SET [Name] = @Name, Breed = @Breed, BirthDate = @BirthDate, Sex = @Sex, Price = @Price, [Status] = @Status
	WHERE AnimalId = @AnimalId
END