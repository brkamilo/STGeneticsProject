USE [STGenetics]
GO

SELECT *
FROM Animal
WHERE Sex = 'Female' AND BirthDate < DATEADD(YEAR, -2, GETDATE())
ORDER by [Name] ASC
