USE [STGenetics]
GO

SELECT Sex, COUNT(Sex) AS Quantity
FROM Animal
GROUP BY Sex